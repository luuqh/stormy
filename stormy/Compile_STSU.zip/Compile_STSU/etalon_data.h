! $Id: etalon_data.h 697 2011-04-11 12:35:17Z gcambon $
!
!======================================================================
! ROMS_AGRIF is a branch of ROMS developped at IRD and INRIA, in France
! The two other branches from UCLA (Shchepetkin et al) 
! and Rutgers University (Arango et al) are under MIT/X style license.
! ROMS_AGRIF specific routines (nesting) are under CeCILL-C license.
! 
! ROMS_AGRIF website : http://roms.mpl.ird.fr
!======================================================================
!

        check_point(1)=1
        etalon_line(1)=
     &    '1.173790936E-05 2.5312396E+01 2.5312408E+01 2.2335473E+15'
        check_point(2)=8
        etalon_line(2)=
     &    '1.776849030E-04 2.5311704E+01 2.5311881E+01 2.2335495E+15'
        check_point(3)=16
        etalon_line(3)=
     &    '3.640907476E-04 2.5298845E+01 2.5299209E+01 2.2335485E+15'
        check_point(4)=32
        etalon_line(4)=
     &    '4.488098981E-04 2.5308054E+01 2.5308503E+01 2.2335462E+15'
        check_point(5)=64
        etalon_line(5)=
     &    '2.598257394E-04 2.5300922E+01 2.5301181E+01 2.2335491E+15'
        check_point(6)=128
        etalon_line(6)=
     &    '2.935546139E-04 2.5304139E+01 2.5304433E+01 2.2335505E+15'


